from celery import shared_task
import pandas as pd
from .models import UploadedFile

@shared_task
def process_csv(file_path):
    try:
        df = pd.read_csv(file_path)

        # Debugging: Print first few rows
        print(df.head())

        # Ensure column names are stripped
        df.columns = df.columns.str.strip()

        # Calculations
        total_revenue = df['Sales'].sum()
        average_discount = df['Discount'].mean()
        best_selling_product = df.groupby('Product Name')['Quantity'].sum().idxmax()
        most_profitable_product = df.groupby('Product Name')['Profit'].sum().idxmax()
        max_discount_product = df.loc[df['Discount'].idxmax(), 'Product Name']

        return {
            'total_revenue': total_revenue,
            'average_discount': average_discount,
            'best_selling_product': best_selling_product,
            'most_profitable_product': most_profitable_product,
            'max_discount_product': max_discount_product,
        }

    except Exception as e:
        return {'error': str(e)}
