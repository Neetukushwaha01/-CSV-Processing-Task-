
import pandas as pd
from django.shortcuts import render
from .forms import FileUploadForm
from .models import UploadedFile

def upload_file(request):
    data = None
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_file = form.save()
            file_path = uploaded_file.file.path


            df = pd.read_csv(file_path)
            data = df.to_dict(orient='records')

    else:
        form = FileUploadForm()

    return render(request, 'upload.html', {'form': form, 'data': data})

# from django.shortcuts import render, redirect
# from django.core.files.storage import FileSystemStorage
# from .models import UploadedFile
# from .tasks import process_csv
#
# def upload_csv(request):
#     calculations = None
#
#     if request.method == 'POST' and request.FILES['csv_file']:
#         file = request.FILES['csv_file']
#         fs = FileSystemStorage()
#         filename = fs.save(file.name, file)
#         file_path = fs.path(filename)
#
#         # Save to database
#         csv_upload = UploadedFile.objects.create(file=file)
#
#         # Process asynchronously
#         task = process_csv.delay(file_path)
#
#         # Wait for task completion (optional)
#         calculations = task.get()
#
#     return render(request, 'upload.html', {'calculations': calculations})


