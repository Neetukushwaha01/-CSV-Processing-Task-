from django.apps import AppConfig


class CsvAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'csv_app'
